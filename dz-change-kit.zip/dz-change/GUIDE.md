# DZ Change Devise : du dossier à l'APK

Ce dossier contient l'application prête à être mise en ligne :

- `index.html` : l'application
- `rates.json` : les taux du jour (officiel, achat et vente au Square)
- `manifest.webmanifest`, `sw.js`, `icon-192.png`, `icon-512.png` : ce qui permet de l'installer comme une vraie application, même sans connexion

## Étape 1. Créer le dépôt sur GitHub

1. Va sur github.com et crée un compte gratuit (ou connecte-toi).
2. Clique sur « New repository ». Nom : `dz-change`. Choisis « Public ». Valide.

## Étape 2. Déposer les 6 fichiers

1. Dans le dépôt, clique sur « Add file », puis « Upload files ».
2. Glisse les 6 fichiers du dossier (pas le dossier lui-même, ni ce guide).
3. Clique sur « Commit changes ».

## Étape 3. Activer la page web

1. Dans le dépôt : « Settings », puis « Pages ».
2. Sous « Branch », choisis `main` et `/ (root)`, puis « Save ».
3. Attends 1 à 2 minutes. L'adresse sera : `https://TON-NOM.github.io/dz-change/`
4. Ouvre-la sur ton téléphone. L'application doit s'afficher avec les taux. Dans le menu de Chrome, « Installer l'application » la place sur ton écran d'accueil.

## Étape 4. Fabriquer l'APK (sans programmation)

1. Va sur pwabuilder.com et colle l'adresse de l'étape 3, puis « Start ».
2. Clique sur « Package for stores », puis « Android ».
3. Remplis : nom « DZ Change Devise », identifiant `com.dzchange.devise`. Pour la clé de signature, choisis de la créer (« New »).
4. Clique sur « Generate » et télécharge le fichier zip.
5. Dans ce zip :
   - le fichier `.apk` s'installe directement sur un téléphone Android ;
   - le fichier `.aab` sert pour Google Play ;
   - le fichier de clé de signature et son mot de passe sont à **conserver précieusement** : sans eux, tu ne pourras plus publier de mise à jour de l'application.

Les écrans de PWABuilder peuvent changer légèrement, mais les étapes restent les mêmes.

## Étape 5. Installer et tester l'APK

Envoie le fichier `.apk` sur ton téléphone (WhatsApp, Telegram ou câble USB), ouvre-le et autorise l'installation depuis cette source si Android le demande.

## Étape 6. Publier

- **Google Play :** frais uniques d'environ 25 dollars, vérification d'identité, et il faut une politique de confidentialité en ligne (l'application ne collecte aucune donnée, une page très courte suffit). Vérifie que ton moyen de paiement est accepté pour l'Algérie.
- **Sans Google Play :** Aptoide, APKPure, Huawei AppGallery, ou partage direct du fichier `.apk` sur Facebook, TikTok et WhatsApp.

## Mise à jour quotidienne des taux

L'application lit `rates.json` à chaque ouverture, donc **l'APK n'a pas besoin d'être refait** pour changer les taux : il suffit de mettre à jour ce fichier sur GitHub (icône crayon, puis « Commit changes »).

Pour que ce soit fait automatiquement chaque matin, dis-moi le nom de ton dépôt (`TON-NOM/dz-change`). Je le relie à la tâche quotidienne.

## Publicité dans l'application

L'APK fabriqué avec PWABuilder est ton site web emballé : il ne peut pas afficher les publicités AdMob. Pour des publicités intégrées, il faudra plus tard une version native (projet Capacitor avec AdMob). Pour démarrer, la promotion de l'application elle-même (Facebook, TikTok, groupes) fonctionne sans ça.
